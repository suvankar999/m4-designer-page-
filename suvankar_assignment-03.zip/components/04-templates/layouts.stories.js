import m4pagetwig from './m4page.twig';
import fullWidthTwig from './full-width.twig';
import withSidebarTwig from './with-sidebar.twig';

import mainMenu from '../02-molecules/menus/main-menu/main-menu.yml';
import socialMenu from '../02-molecules/menus/social/social-menu.yml';
import footerMenu from '../02-molecules/menus/inline/inline-menu.yml';
import bannerData from '../03-organisms/site/banner/banner.yml';
import gridtextData from '../03-organisms/grid/gridtext/gridtext.yml';
import menubarData from '../02-molecules/menus/menubar/menubar.yml';
import IMGgridData from '../03-organisms/grid/IMGgrid/IMGgrid.yml';
import imgcolumnData from '../03-organisms/grid/imgcolumn/imgcolumn.yml';
import myskillData from '../03-organisms/grid/skill/skill.yml';
import cardgridData from '../03-organisms/grid/cardgrid/cardgrid.yml';
import awardData from '../03-organisms/grid/award/award.yml';
import imgsectionData from '../03-organisms/grid/imgsection/imgsection.yml';
import footermapData from '../03-organisms/site/footermap/footermap.yml';
import parallaxData from '../03-organisms/grid/parallax/parallax.yml';
/**
 * Storybook Definition.
 */
export default {
  title: 'Templates/Layouts',
  parameters: {
    layout: 'fullscreen',
  },
};

export const fullWidth = () =>
  fullWidthTwig({ ...mainMenu, ...socialMenu, ...footerMenu });

export const withSidebar = () =>
  withSidebarTwig({ ...mainMenu, ...socialMenu, ...footerMenu });

export const M4DesignerPage = () =>
  m4pagetwig({
    ...menubarData,
    ...bannerData,
    ...gridtextData,
    ...IMGgridData,
    ...imgcolumnData,
    ...myskillData,
    ...cardgridData,
    ...awardData,
    ...imgsectionData,
    ...parallaxData,
    ...footermapData,
  });
