import placeHolderTwig from './place-holder.twig';

/**
 * Storybook Definition.
 */
export default { title: 'Templates/Place Holder' };

export const placeHolder = () => placeHolderTwig();
