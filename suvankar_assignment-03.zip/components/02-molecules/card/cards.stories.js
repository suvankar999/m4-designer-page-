import card from './card.twig';
import cardtitle from './cardtitle/cardtitle.twig';
import slider from './slider/slider.twig';
import numbercard from './numbercard/numbercard.twig';
import designer from './designer/designer.twig';
import cardData from './card.yml';
import cardtitleData from './cardtitle/cardtitle.yml';
import designerData from './designer/designer.yml';
import numbercardData from './numbercard/numbercard.yml';
import sliderData from './slider/slider.yml';
import cardBgData from './card-bg.yml';
import './designer/designer.scss';
import './cardtitle/cardtitle.scss';
import './slider/script';
import 'slick-carousel/slick/slick';
import '../../../node_modules/slick-carousel/slick/slick.css';
import '../../../node_modules/slick-carousel/slick/slick-theme.css';
/**
 * Storybook Definition.
 */
export default { title: 'Molecules/Cards' };

export const cardExample = () => card(cardData);

export const CardTitle = () => cardtitle(cardtitleData);

export const NumberCard = () => numbercard(numbercardData);

export const designerCard = () => designer(designerData);

export const ParallaxSlider = () => slider(sliderData);

export const cardWithBackground = () => card({ ...cardData, ...cardBgData });
