import heading from './headings/_heading.twig';
import customheading from './headings/customheading/customheading.twig';
import demoheader from './headings/demoheader/demoheader.twig';
import subheading from './headings/subheading/subheading.twig';
import blockquote from './text/02-blockquote.twig';
import demopara from './text/demopara.twig';
import pre from './text/05-pre.twig';
import paragraph from './text/03-inline-elements.twig';
import customheadingData from './headings/customheading/customheading.yml';
import subheadingData from './headings/subheading/subheading.yml';
import demoheaderData from './headings/demoheader/demoheader.yml';
import blockquoteData from './text/blockquote.yml';
import demoparaData from './text/demopara.yml';
import headingData from './headings/headings.yml';

export default { title: 'Atoms/Text' };

// Loop over items in headingData to show each one in the example below.
const headings = headingData.map((d) => heading(d)).join('');

const demoheading = customheadingData.map((d) => customheading(d)).join('');

const subhead = subheadingData.map((d) => subheading(d)).join('');

const demohead = demoheaderData.map((d) => demoheader(d)).join('');

export const headingsExamples = () => headings;

export const subheadings = () => subhead;

export const NavbarHeading = () => demoheading;

export const demoheaders = () => demohead;

export const blockquoteExample = () => blockquote(blockquoteData);

export const paragraphExample = () => demopara(demoparaData);

export const preformatted = () => pre();

export const random = () => paragraph();
