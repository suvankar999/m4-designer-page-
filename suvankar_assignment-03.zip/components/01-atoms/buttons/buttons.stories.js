// Buttons Stories
import button from './button.twig';
import btn from './btn.twig';
import hoverbtn from './hoverbtn.twig';

import buttonData from './button.yml';
import btnData from './btn.yml';
import hoverbtnData from './hoverbtn.yml';
import buttonAltData from './button-alt.yml';

/**
 * Storybook Definition.
 */
export default { title: 'Atoms/Button' };

export const twig = () => button(buttonData);

export const BTN = () => btn(btnData);

export const HoverBtn = () => hoverbtn(hoverbtnData);

export const twigAlt = () => button(buttonAltData);
